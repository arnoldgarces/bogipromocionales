<a id="Whatsapp-header" href="#">
    <span class="site-name"><img src="img/whatsapp.png" width="20" height="20" /> (57) + 3183378462 <img src="img/whatsapp.png" width="20" height="20" />(57) + 3118086832<br /> Heisen Boada Giron    </span>
    </a> 
	<nav>
		<ul>
			<li><a href="<?php echo $urlweb ?>">Inicio</a></li>
      		<li><a title="Productos" href="<?php echo $urlweb ?>productos.php?date=0">Productos</a></li>
       	    <li><a title="Cotizaciones" href="<?php echo $urlweb ?>/solicitaCotizacion.php">�Solicita tu cotizacion!</a></li>
			<li><a title="Acerca de nosotros" href="<?php echo $urlweb ?>/acercade.php">Acerca de</a></li>
		</ul>
	</nav><!-- / nav -->