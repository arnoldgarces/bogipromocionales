	<ul id="nov"> 
		<li><a title="Inicio" href="#">Inicio</a></li>
		<li><a title="Productos" href="#">Productos</a></li>
	    <li><a title="Cotizaciones" href="#">�Solicita tu cotizacion!</a></li>
		<li><a title="Nosotros" href="#">Nosotros</a></li>
	</ul>