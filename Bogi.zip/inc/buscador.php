  <div id="Buscador">
      <input name="buscar" type="text" id="buscar" size="7" placeholder="Buscar.." />
  </div>