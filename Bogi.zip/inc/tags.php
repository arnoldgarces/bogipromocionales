<div id="sectio_r" style="height: 60px">
      <div id="side_r">mejores tags</div>
    <a href="#"><div class="tags_t">Tags</div></a>
    <a href="#"><div class="tags_t">Tags2</div></a>
    <a href="#"><div class="tags_t">Tags3</div></a>
     </div>