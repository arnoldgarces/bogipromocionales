<div id="sectio_r">
      <div id="side_r">ultimos comentarios</div>
      <span class="txt_side"><a href="ver_post.php">Enlace a último comentario de...</a></span><br />
      <span class="txt_side"><a href="ver_post.php">Enlace a último comentario de...</a></span>
    </div>